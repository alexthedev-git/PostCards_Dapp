module.exports = {
  transpileDependencies: [
    'vuetify',
  ],
};
